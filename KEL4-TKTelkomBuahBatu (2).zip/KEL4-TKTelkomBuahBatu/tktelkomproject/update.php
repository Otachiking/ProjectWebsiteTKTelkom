<?php 
 
include 'koneksiakun.php';
$id = $_POST['id'];
$nama_siswa = $_POST['nama_siswa'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$kelas = $_POST['kelas'];
$nama_ortu = $_POST['nama_ortu'];
$tahun_ajaran = $_POST['tahun_ajaran'];
 
$hasil="UPDATE user SET nama_siswa='$nama_siswa', jenis_kelamin='$jenis_kelamin', kelas='$kelas', nama_ortu='$nama_ortu', tahun_ajaran='tahun_ajaran' WHERE id='$id'";
mysqli_query($koneksi, $hasil);
 
header("location:iHomeAdmin.php?halaman=DaftarSiswa?pesan=update");
?>