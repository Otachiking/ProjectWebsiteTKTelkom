<?php
 include 'koneksiakun.php';
$id = $_GET['id'];
$query="DELETE from register where id='$id'";
mysqli_query($koneksi, $query);
echo "<script>alert('Objek Sudah Dihapus.');window.location='HomeAdmin.php';</script>";

?>

