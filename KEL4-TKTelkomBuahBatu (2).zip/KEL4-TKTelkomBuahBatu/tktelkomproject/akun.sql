-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 25 Apr 2020 pada 10.09
-- Versi Server: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `akun`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `jenis_pesan` char(12) NOT NULL,
  `pesan` text NOT NULL,
  `gambar` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `feedback`
--

INSERT INTO `feedback` (`id`, `nama`, `email`, `jenis_pesan`, `pesan`, `gambar`) VALUES
(2, 'test', 'test@gmail.com', 'o', 'Woi', ''),
(3, 'test', 'test@gmail.com', 'Komentar', 'WOOO BAGOSSS', '3.png'),
(4, 'awaw', 'bla@gmail', 'Komentar', 'Wawwww', ''),
(5, 'iqbal', 'iqbalrcold@gmail.com', 'Komentar', 'Waahh keren', ''),
(6, 'Muhammad Iqbal Rasyid', 'iqbaltampan321@gmail.com', 'Komentar', 'Waaahh keren sekaleeee', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gurustaff`
--

CREATE TABLE IF NOT EXISTS `gurustaff` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(15) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `gurustaff`
--

INSERT INTO `gurustaff` (`id`, `nama`, `jenis_kelamin`, `no_hp`, `status`) VALUES
(1, 'Lucia Tyagita Rani Caesara', 'Perempuan', '082119990004', 'Kepala Sekolah'),
(2, 'Melissa Chyntia Dewi', 'Perempuan', '082119994324', 'Wakil Kepala Sekolah'),
(3, 'Syifa Rohmati Mashfufah', 'Perempuan', '082119870874', 'Guru'),
(4, 'Lia Yulianti', 'Perempuan', '081347472843', 'Guru'),
(5, 'Meilana Diyah setiyaningsih', 'Perempuan', '088936373932', 'Guru'),
(6, 'Shinta Sunanti', 'Perempuan', '0856556687', 'Guru'),
(7, 'Sitoresmi Vina Wulandari', 'Perempuan', '08111707904', 'Bendahara'),
(8, 'Indry Silviana Safitri', 'Perempuan', '085648700892', 'Sekretaris'),
(9, 'Aditya Sunu Subiakto', 'Laki-laki', '081212029450', 'Staff'),
(10, 'Muhammad Iqbal Rasyid', 'Laki-laki', '081283541989', 'Staff'),
(11, 'Edward Yosafat Sirait', 'Laki-laki', '083899937909', 'Staff');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppdb`
--

CREATE TABLE IF NOT EXISTS `ppdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(80) NOT NULL,
  `jk` char(2) NOT NULL,
  `tempatl` varchar(30) NOT NULL,
  `tanggall` date NOT NULL,
  `umur` int(2) NOT NULL,
  `alamat` text NOT NULL,
  `kelas` char(10) NOT NULL,
  `nama_a` varchar(50) NOT NULL,
  `hp_a` int(50) NOT NULL,
  `nama_b` varchar(50) NOT NULL,
  `hp_b` int(50) NOT NULL,
  `file` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `ppdb`
--

INSERT INTO `ppdb` (`id`, `nama_lengkap`, `jk`, `tempatl`, `tanggall`, `umur`, `alamat`, `kelas`, `nama_a`, `hp_a`, `nama_b`, `hp_b`, `file`) VALUES
(1, 'Muhammad Iqbal Rasyid', 'L', 'Jakarta', '2004-01-07', 16, 'Ada dehhh', 'TK-B', 'Yusuf Arifin', 2147483638, 'Widya Ramadhani Safitri', 2147483647, 'ppdb.pdf');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_produk` varchar(50) NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `ukuran` char(2) NOT NULL,
  `gender` char(20) NOT NULL,
  `harga` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `nama_produk`, `gambar`, `ukuran`, `gender`, `harga`) VALUES
(1, 'Seragam Merah Putih', 'merahputih.jpg', '', '', 90),
(2, 'Seragam Hijau', 'hijau.jpg', '', '', 90),
(3, 'Seragam Pramuka', 'pramuka.jpg', '', '', 90),
(4, 'Seragam Kuning', 'kuning.jpg', '', '', 90),
(5, 'Paket Pintar Super Lengkap TK-A (SM 1)', 'bukua1.jpg', '', '', 50),
(6, 'Paket Pintar Super Lengkap TK-A (SM 2)', 'bukua2.jpg', '', '', 50),
(7, 'Paket Pintar Super Lengkap TK-B (SM 1)', 'bukub1.jpg', '', '', 50),
(8, 'Paket Pintar Super Lengkap TK-B (SM 2)', 'bukub2.jpg', '', '', 50);

-- --------------------------------------------------------

--
-- Struktur dari tabel `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `nama_ortu` varchar(50) NOT NULL,
  `nama_anak` varchar(50) NOT NULL,
  `no_hp` int(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `tipe_user` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data untuk tabel `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `nama_ortu`, `nama_anak`, `no_hp`, `password`, `tipe_user`) VALUES
(14, 'test', 'test@gmail.com', 'test', 'test', 123, 'test', 'user'),
(15, 'admin', 'admin@gmail.com', 'admin', 'admin', 2147483647, 'admin123', 'admin'),
(16, 'Otachiking123', 'iqbalrcold@gmail.com', 'Yusuf Arifin', 'Muhammad Rafli Aqila', 2147483647, 'ayamgoreng', 'user'),
(17, 'a', 'ebetbe@gmail.com', 'daaf', 'afef', 0, '123', 'user'),
(18, 'guru', 'guru@gmail.com', 'guru', 'guruuu', 1993849, 'guru123', 'user'),
(19, 'Iqbal', 'iqbalrcold@gmail.com', 'Yusuf Arifin', 'Muhammad Iqbal Rasyid', 2147483647, '123456', 'user'),
(20, 'Iqbal Ganteng', 'iqbalrcoldDDD@gmail.com', 'Yusuf Arifin', 'Muhammad Iqbal Rasyid', 2147483647, '123', 'user');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `nama_siswa` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(13) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `nama_ortu` varchar(50) NOT NULL,
  `tahun_ajaran` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `nama_siswa`, `jenis_kelamin`, `kelas`, `nama_ortu`, `tahun_ajaran`) VALUES
(1, 'Muhammad Iqbal Rasyid', 'Laki-laki', 'TK-A', 'Yusuf Arifin', '2019'),
(2, 'Muhammad Ridwan Arsyad', 'Laki-laki', 'TK-A', 'Yusuf Arifin', '2019'),
(3, 'Muhammad Rafli Aqila', 'Laki-laki', 'TK-A', 'Yusuf Arifin', '2019'),
(4, 'Anisa Nur Aini', 'Perempuan', 'TK-A', 'Yusuf Arifin', '2019');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
