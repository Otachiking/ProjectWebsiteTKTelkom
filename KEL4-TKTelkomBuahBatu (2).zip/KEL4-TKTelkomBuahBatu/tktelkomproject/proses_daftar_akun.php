<?php 
//Tetap memanggil file 'koneksi.php' sbelumnya untuk melakukan koneksi data base
include'koneksiakun.php';


	//membuat variabel untuk menampung data dari form
	$username		=$_POST['username'];
	$nama_ortu    	=$_POST['nama_ortu'];
	$nama_anak 	    =$_POST['nama_anak'];
	$no_hp 			=$_POST['no_hp'];
	$email 			=$_POST['email'];
	$password		=$_POST['password'];
	//$gambar_produk  =$_FILE['gambar_produk']['name']; 
	//Jalankan query INSERT untuk menambah data ke database pastidak sesuai urutan (id mah gak usah soalnya kan udah dibikin otomatis)
		$query="INSERT INTO register (username,nama_ortu,nama_anak,no_hp,email,password) VALUES ('$username', '$nama_ortu', '$nama_anak','$no_hp', '$email','$password')";
		$result = mysqli_query($koneksi,$query);
		$last_id = mysqli_insert_id($koneksi);
		// Periksa query apakah ada yang error?

		$tambah_user="UPDATE `akun`.`register` SET `tipe_user` = 'user' WHERE `register`.`id` = '".$last_id."'";
		// $hasil= mysqli_query($koneksi,$hasil);

		if(!$result){
			die ("Query gagal dijalankan". mysqli_errno($koneksi)."-". mysqli_error($koneksi));
		}else{
			
			//tampil alert dan akan redirect ke halaman index.php
			//silahkan ganti index.php sesuai halaman yang akan dituju

		echo "<script>alert('Selamat! Akun berhasil dibuat.');window.location='Login.php';</script>";
	}
	
?>