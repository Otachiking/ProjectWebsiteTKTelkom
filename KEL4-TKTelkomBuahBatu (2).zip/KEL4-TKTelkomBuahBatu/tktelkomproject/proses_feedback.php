<?php 
//Tetap memanggil file 'koneksi.php' sbelumnya untuk melakukan koneksi data base
include'koneksiakun.php';


  // // Initialize message variable
  // $msg = "";

  // // If upload button is clicked ...
  // if (isset($_POST['upload'])) {
  // 	// Get image name
  // 	$image = $_FILES['image']['name'];
  // 	// Get text
  // 	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);

  // 	// image file directory
  // 	$target = "images/".basename($image);

  // 	$sql = "INSERT INTO images (image, image_text) VALUES ('$image', '$image_text')";
  // 	// execute query
  // 	mysqli_query($db, $sql);

  // 	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  // 		$msg = "Image uploaded successfully";
  // 	}else{
  // 		$msg = "Failed to upload image";
  // 	}
  // }
  // $result = mysqli_query($db, "SELECT * FROM images");


	//membuat variabel untuk menampung data dari form
	$nama				=$_POST['nama'];
	$email   			=$_POST['email'];
	$jenis_pesan 	    =$_POST['jenis_pesan'];
	$pesan				=$_POST['pesan'];
	$gambar 			=$_FILES['gambar']['name'];
	//$gambar_produk  =$_FILE['gambar_produk']['name']; 
	//Jalankan query INSERT untuk menambah data ke database pastidak sesuai urutan (id mah gak usah soalnya kan udah dibikin otomatis)
		$query="INSERT INTO feedback (nama,email,jenis_pesan,pesan,gambar) VALUES ('$nama', '$email', '$jenis_pesan','$pesan', '$gambar')";
		$result = mysqli_query($koneksi,$query);
		// Periksa query apakah ada yang error?

		if(!$result){
			die ("Query gagal dijalankan". mysqli_errno($koneksi)."-". mysqli_error($koneksi));
		}else{
			//tampil alert dan akan redirect ke halaman index.php
			//silahkan ganti index.php sesuai halaman yang akan dituju
		echo "<script>alert('Selamat! Feedback berhasil dikirim.');window.location='HubungiKami.php';</script>";
	}
	
?>