<?php 
//Tetap memanggil file 'koneksi.php' sbelumnya untuk melakukan koneksi data base
include'callingsql.php';


	//membuat variabel untuk menampung data dari form
	$nama_produk    =$_POST['nama_produk'];
	$deskripsi 	    =$_POST['deskripsi'];
	$harga_beli 	=$_POST['harga_beli'];
	$harga_jual 	=$_POST['harga_jual'];
	$gambar_produk	=$_FILES['gambar_produk']['name'];
	//$gambar_produk  =$_FILE['gambar_produk']['name']; 
	//Jalankan query INSERT untuk menambah data ke database pastidak sesuai urutan (id mah gak usah soalnya kan udah dibikin otomatis)
		$query="INSERT INTO register (nama_produk,deskripsi,harga_beli,harga_jual,gambar_produk) VALUES ('$nama_produk', '$deskripsi', '$harga_beli', '$harga_jual','$gambar_produk')";
		$result = mysqli_query($koneksi,$query);
		// Periksa query apakah ada yang error?

		if(!$result){
			die ("Query gagal dijalankan gaed". mysqli_errno($koneksi)."-". mysqli_error($koneksi));
		}else{
			//tampil alert dan akan redirect ke halaman index.php
			//silahkan ganti index.php sesuai halaman yang akan dituju
		echo "<script>alert('Data berhasil ditambah.');window.location='index.php';</script>";
	}
	
?>