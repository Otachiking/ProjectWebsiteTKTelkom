<?php
	$host="localhost";
	$user="root";
	$pass="";
	$nama_db="akun"; //sesuaikan dengan nama database kamu yaa

	$koneksi=mysqli_connect($host,$user,$pass,$nama_db); //pastikan urutan datanya berurutan yaa jangan sampe tertukar ea

	if(!$koneksi){ //jadi ini maksudnya, jika tidak cocok, maka akan batal. tapi kalau cocok, pesan dibawah tidak akan muncul =)
		die("Koneksi dengan database gagal".
			mysql_connect_error());
	}
?>