<?php 
//Tetap memanggil file 'koneksi.php' sbelumnya untuk melakukan koneksi data base
include'koneksiakun.php';


  // // Initialize message variable
  // $msg = "";

  // // If upload button is clicked ...
  // if (isset($_POST['upload'])) {
  // 	// Get image name
  // 	$image = $_FILES['image']['name'];
  // 	// Get text
  // 	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);

  // 	// image file directory
  // 	$target = "images/".basename($image);

  // 	$sql = "INSERT INTO images (image, image_text) VALUES ('$image', '$image_text')";
  // 	// execute query
  // 	mysqli_query($db, $sql);

  // 	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  // 		$msg = "Image uploaded successfully";
  // 	}else{
  // 		$msg = "Failed to upload image";
  // 	}
  // }
  // $result = mysqli_query($db, "SELECT * FROM images");


	//membuat variabel untuk menampung data dari form
	$nama_lengkap		=$_POST['nama_lengkap'];
  $jk             =$_POST['jk'];
  $tempatl        =$_POST['tempatl'];
  $tanggall       =$_POST['tanggall'];
  $umur           =$_POST['umur'];
  $alamat         =$_POST['alamat'];
  $kelas          =$_POST['kelas'];
  $nama_a         =$_POST['nama_a'];
  $hp_a           =$_POST['hp_a'];
  $nama_b         =$_POST['nama_b'];
  $hp_b           =$_POST['hp_b'];
	$file     			=$_FILES['gambar']['name'];
	//$gambar_produk  =$_FILE['gambar_produk']['name']; 
	//Jalankan query INSERT untuk menambah data ke database pastidak sesuai urutan (id mah gak usah soalnya kan udah dibikin otomatis)
		$query="INSERT INTO ppdb (nama_lengkap,jk,tempatl,tanggall,umur,alamat,kelas,nama_a,hp_a,nama_b,hp_b,file) VALUES ('$nama_lengkap', '$jk', '$tempatl', '$tanggall', '$umur', '$alamat', '$kelas', '$nama_a', '$hp_a', '$nama_b', '$hp_b', '$file')";
		$result = mysqli_query($koneksi,$query);
		// Periksa query apakah ada yang error?

		if(!$result){
			die ("Query gagal dijalankan". mysqli_errno($koneksi)."-". mysqli_error($koneksi));
		}else{
			//tampil alert dan akan redirect ke halaman index.php
			//silahkan ganti index.php sesuai halaman yang akan dituju
		echo "<script>alert('Selamat! Formulir PPDB berhasil dikirim.');window.location='HubungiKami.php';</script>";
	}
	
?>